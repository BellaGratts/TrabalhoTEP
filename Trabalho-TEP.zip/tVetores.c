#ifdef tipado_
#ifdef tipo_
#ifdef formato_

struct tipado_(vetor_st){     
  int n;
  int N=100;
  int i;
  tipo_* elementos[N];

};

//funçao que corrige o numero maximo de elementos        
int corrigeNumMaximo(int n, int N){
  if(N == n){
    N = (N*2);
    return N;
  }
  if(n < N/4){
    N= (N/2);
    return N;
  }
  return N;
}

//funçao que cria um vetor
tipado_(vetor_t)* tipado_(criaVetor)( tipo_ elementos[]){
  tipado_(vetor_t)* vetor[] = (tipado_(vetor_t)*) malloc(sizeof(tipado_(vetor_t)));
   if (vetor == NULL){
    printf("Erro de alocação do vetor\n");
    exit(1);
   }
   
}

//funçao que destroi um vetor
void tipado_(destroiVetor)(tipado_(vetor_t)* vetor){
  free(vetor);
}

//funçao que atribui uma cópia do vetor a outro vetor já existente


//funçao que cria uma cópia do vetor, criando um novo vetor





#endif
#endif
#endif