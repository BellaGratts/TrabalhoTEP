Coisas específicas para fazer:
-
Racionais:
-
-Fazer função de raiz do racional e converte double pra racional.

-Fazer a parte de arquivo CSV.
____________________________________________________________________
Complexos:
-
-Implementar o macro para racionais.

-Fazer as funções "atribuir novo valor à magnitude de um número complexo (módulo) mantendo seu ângulo" e "atribuir novo valor à fase de um número complexo (ângulo) mantendo o seu módulo".

-Fazer as funçoes de conversão de tipos em complexos.

-Fazer a parte de arquivo CSV.
____________________________________________________________________
Falta:
-
-Vetores