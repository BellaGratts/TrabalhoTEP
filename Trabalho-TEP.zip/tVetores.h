#ifndef TVETORES_GENERICO_H
#define TVETORES_GENERICO_H

typedef struct tipado_(vetor_st)* tipado_(vetor_pt);
typedef struct tipado_(vetor_st) tipado_(vetor_t);

int corrigeNumMaximo(int n, int N);

tipado_(vetor_t)* tipado_(criaVetor)( tipo_ elementos[]);

void tipado_(destroiVetor)(tipado_(vetor_t)* vetor);

#undef TVETORES_H

#endif